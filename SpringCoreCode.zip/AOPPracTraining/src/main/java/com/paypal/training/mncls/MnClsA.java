package com.paypal.training.mncls;

import org.springframework.aop.framework.ProxyFactory;
import compaypal.training.aopcls.InterestCalculator;
import compaypal.training.aopcls.SecurityAspect;

public class MnClsA {
	public static void main(String[] args) {
		ProxyFactory fact=new ProxyFactory();
		fact.addAdvice(new SecurityAspect());
		fact.setTarget(new InterestCalculator());
		InterestCalculator ii=(InterestCalculator)fact.getProxy();
		float intr=ii.calcInterest(100, 4, 2);
		System.out.println(intr);
	}
}
