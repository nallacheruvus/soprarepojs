package com.paypal.training.mncls;

import org.springframework.aop.framework.ProxyFactory;

import compaypal.training.aopcls.MyKeyGen;
import compaypal.training.aopcls.WeakKeygenChecker;

public class MnClsB {
	public static void main(String[] args) {
		for (int i = 0; i < 1000; i++) {
			ProxyFactory fact = new ProxyFactory();
			fact.addAdvice(new WeakKeygenChecker());
			fact.setTarget(new MyKeyGen());
			MyKeyGen kg = (MyKeyGen) fact.getProxy();
			System.out.println(kg.retKey());
		}
	}
}
