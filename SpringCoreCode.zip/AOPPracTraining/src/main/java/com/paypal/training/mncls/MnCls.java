package com.paypal.training.mncls;

import org.springframework.aop.framework.ProxyFactory;

import compaypal.training.aopcls.LoggerAspect;
import compaypal.training.aopcls.MyCalcCls;
import compaypal.training.aopcls.MyClass;

public class MnCls {

	public static void main(String[] args) {
		System.out.println("Method interceptor tests");
		ProxyFactory fact=new ProxyFactory();
		fact.addAdvice(new LoggerAspect());
		fact.setTarget(new MyCalcCls());
		MyCalcCls cls=(MyCalcCls)fact.getProxy();
//		System.out.println(cls.addNum(2, 3));
		System.out.println(cls.mulNum(2, 3));
		
//		for (int i = 0; i < 10; i++) {
//			MyClass cc=new MyClass();
//		}
	}
}
