package com.paypal.training.mncls;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.ParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class FirstSpelProg {

	public static void main(String[] args) {
		ExpressionParser parser=new SpelExpressionParser();
//		Expression exp=parser.parseExpression("5+4");
//		Integer msg=(Integer)exp.getValue();
//		System.out.println(msg);
		
//		Expression exp=parser.parseExpression("(9+1)*10");
//		Integer msga=(Integer)exp.getValue();
//		System.out.println(msga);
		
//		Expression exp=parser.parseExpression("A Window Opens", ParserContext.TEMPLATE_EXPRESSION);
//		System.out.println(exp.getValue().toString());
		
//		Expression exp=parser.parseExpression("Doors Operating System",ParserContext.TEMPLATE_EXPRESSION);
//		byte[] bArr=exp.getValue().toString().getBytes();
//		for (int i = 0; i < bArr.length; i++) {
//			System.out.println((char)bArr[i]);
//		}
		
		System.out.println(parser.parseExpression("10*10/2").getValue());
		System.out.println(parser.parseExpression("new java.util.Date()").getValue());
		//ANTLR
		
		
		
	}

}
