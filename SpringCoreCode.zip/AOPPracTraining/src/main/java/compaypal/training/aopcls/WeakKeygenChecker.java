package compaypal.training.aopcls;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

public class WeakKeygenChecker implements AfterReturningAdvice {
	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		System.out.println("Entering after returning advice");
		System.out.println(method.getName());
		System.out.println(target.toString());
		if((Integer)returnValue<=0) {
			//throw new IllegalArgumentException("Weak key returned algorithm is buggy");
			throw new MyException(null);
		}
	}
}
