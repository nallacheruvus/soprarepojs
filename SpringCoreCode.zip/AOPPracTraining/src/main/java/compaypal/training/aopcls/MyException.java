package compaypal.training.aopcls;

import java.lang.reflect.UndeclaredThrowableException;

public class MyException extends UndeclaredThrowableException {
	public MyException(Throwable undeclaredThrowable) {
		super(undeclaredThrowable);
	}

	@Override
	public String getMessage() {
		String mymsg="This is the result of returning a key which is irrelevant to our current context";
		return mymsg;
	}
}
