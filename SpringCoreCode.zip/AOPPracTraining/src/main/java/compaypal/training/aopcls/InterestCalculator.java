package compaypal.training.aopcls;

public class InterestCalculator {
	public float calcInterest(long principal, int numYears, float rate) {
		float inter=(principal*numYears*rate)/100;
		return inter;
	}
}
