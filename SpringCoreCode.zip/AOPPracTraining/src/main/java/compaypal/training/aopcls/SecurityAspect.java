package compaypal.training.aopcls;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class SecurityAspect implements MethodBeforeAdvice {
	public void before(Method method, Object[] args, Object target) throws Throwable {
		System.out.println("Entering the method "+method.getName());
		System.out.println("Method before advice called ");
		for(Object o:args) {
			System.out.println(o);
		}	
		System.out.println("The name of the class is "+target.toString());
	}
}
