package compaypal.training.aopcls;


import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class LoggerAspect implements MethodInterceptor {
	public Object invoke(MethodInvocation invocation) throws Throwable {
		Object[] args=invocation.getArguments();
		String j=invocation.getMethod().getName();
		System.out.println(j);
		for(Object a:args) {
			System.out.println("Argument "+a);
		}
		System.out.println("Method is intercepted");
		Integer a=(Integer)args[0];
		Integer b=(Integer)args[1];
		Integer res=0;
//		Object o=invocation.proceed();
		if(j.equals("addNum")) {
			res=a+b;
		}else {
			res=a*b;
		}
		return res;
	}
}
