package compaypal.training.aopcls;

public class MyCalcCls {
	/**
	 * Returns the sum of two numbers
	 * @param i first param
	 * @param j second param
	 * @return sum
	 */
	public int addNum(int i,int j) {
		return i+j;
	}
	
	/**
	 * Returns the product of two numbers
	 * @param i multiplicand
	 * @param j second parameter
	 * @return product
	 */
	public int mulNum(int i,int j) {
		return i*j;
	}
	
}
