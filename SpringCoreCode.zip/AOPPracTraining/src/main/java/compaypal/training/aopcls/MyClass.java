package compaypal.training.aopcls;

public class MyClass {
	static {
		System.out.println("Only Once");
	}
	
	public MyClass() {
		System.out.println("***constructor called");
	}
}
