package compaypal.training.aopcls;

import java.util.Random;

public class MyKeyGen {
	public int retKey() {
		int u=0;
		Random rr=new Random();
		u=rr.nextInt(10);
		return u;
	}
}
