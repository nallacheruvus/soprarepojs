package com.paypal.training.sprcls;

import org.springframework.stereotype.Service;

@Service("MyServe")
public class MyService {
	public String retTest() {
		String j="";
		for (int i = 1; i <= 10; i++) {
			j+="Log("+i+")="+Math.log(i)+";";
		}
		return j;
	}
}
