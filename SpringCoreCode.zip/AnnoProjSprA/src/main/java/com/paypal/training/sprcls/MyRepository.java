package com.paypal.training.sprcls;

import org.springframework.stereotype.Repository;

@Repository("MyRepo")
public class MyRepository {
	public String retY() {
		String jj="";
		for (int i = 1; i <= 20; i++) {
			jj+="Sqr("+i+")="+Math.pow(i, 2)+";";
		}
		return jj;
	}
}
