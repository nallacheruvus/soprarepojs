//package com.paypal.training.sprcls;
//
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//
//public class MnCls {
//
//	public static void main(String[] args) {
//		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
//		ctx.scan("com.paypal.training.sprcls");
//		ctx.refresh();
//		PropRepo repo=ctx.getBean(PropRepo.class);
//		System.out.println(repo.getDriverName());
//		System.out.println(repo.getUrl());
//		System.out.println(repo.getUsername());
//		System.out.println(repo.getPassword());
//		ctx.close();
//	}
//
//}
