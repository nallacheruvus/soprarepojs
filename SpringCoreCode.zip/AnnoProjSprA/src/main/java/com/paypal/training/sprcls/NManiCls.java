package com.paypal.training.sprcls;

import java.util.Arrays;
import java.util.StringTokenizer;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.paypal.training.sprcls")
@Configuration
public class NManiCls {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext(NManiCls.class);
		ctx.scan("com.paypal.training.sprcls");
		MyService serv=(MyService)ctx.getBean("MyServe");
//		System.out.println(serv.retTest());
		String t=serv.retTest();
//		String[] arr=t.split(";");
//		for(String j:arr) {
//			System.out.println(j);
//		}
//		StringTokenizer tokenizer=new StringTokenizer(t, ";");
//		while(tokenizer.hasMoreTokens()) {
//			System.out.println(tokenizer.nextToken());
//		}
		MyComponent comp=(MyComponent)ctx.getBean("MyComp");
		String n=comp.retNTest();
//		System.out.println(n);
//		StringTokenizer tokenizera=new StringTokenizer(n,";");
//		while(tokenizera.hasMoreElements()) {
//			System.out.println(tokenizera.nextElement());
//		}
		MyRepository repo=(MyRepository)ctx.getBean("MyRepo");
		String nn=repo.retY();
//		System.out.println(nn);
//		Arrays.asList(nn.split(";")).forEach(a->System.out.println(a));
		
		Arrays.asList(ctx.getBeanDefinitionNames()).forEach(a->System.out.println(a));
		
		ctx.close();
	}
}