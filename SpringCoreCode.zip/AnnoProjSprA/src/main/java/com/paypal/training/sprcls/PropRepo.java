//package com.paypal.training.sprcls;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.PropertySource;
//
//@Configuration
//@PropertySource("classpath:app.properties")
//public class PropRepo {
//	private String driverName;
//	private String url;
//	public String getDriverName() {
//		return driverName;
//	}
//	@Value("${db.drivername}")
//	public void setDriverName(String driverName) {
//		this.driverName = driverName;
//	}
//	public String getUrl() {
//		return url;
//	}
//	@Value("${db.url}")
//	public void setUrl(String url) {
//		this.url = url;
//	}
//	public String getUsername() {
//		return username;
//	}
//	@Value("${db.username}")
//	public void setUsername(String username) {
//		this.username = username;
//	}
//	public String getPassword() {
//		return password;
//	}
//	@Value("${db.password}")
//	public void setPassword(String password) {
//		this.password = password;
//	}
//	private String username;
//	private String password;
//}
