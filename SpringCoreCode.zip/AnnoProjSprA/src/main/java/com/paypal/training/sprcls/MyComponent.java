package com.paypal.training.sprcls;

import org.springframework.stereotype.Component;

@Component("MyComp")
public class MyComponent {
	public String retNTest() {
		String j="";
		for (int i = 1; i <= 10; i++) {
			j+="Sqrt("+i+")="+Math.sqrt(i)+";";
		}
		return j;
	}
}
