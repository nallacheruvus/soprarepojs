package com.paypal.training.dao;

import java.util.List;

import javax.sql.DataSource;

import com.paypal.training.models.Books;

public interface BooksDao {
	public void setDataSource(DataSource ds);
	public List<Books> retBooks();
	public void insBooks(Books bb);
	public void upsBooks(Books bb);
	public void delBooks(int bid);
}
