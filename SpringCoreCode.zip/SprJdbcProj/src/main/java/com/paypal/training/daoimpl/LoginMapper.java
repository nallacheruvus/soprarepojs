package com.paypal.training.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.paypal.training.models.Logins;

public class LoginMapper implements RowMapper<Logins> {
	public Logins mapRow(ResultSet rs, int rowNum) throws SQLException {
		Logins lgn=new Logins();
		lgn.setUsername(rs.getString(1));
		lgn.setPassword(rs.getString(2));
		return lgn;
	}
}
