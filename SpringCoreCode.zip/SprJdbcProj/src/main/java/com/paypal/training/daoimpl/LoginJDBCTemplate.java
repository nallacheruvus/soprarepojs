package com.paypal.training.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.paypal.training.dao.BooksDao;
import com.paypal.training.dao.LoginDAO;
import com.paypal.training.models.Books;
import com.paypal.training.models.Logins;

public class LoginJDBCTemplate implements LoginDAO, BooksDao {
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource ds) {
		this.dataSource=ds;
		this.jdbcTemplate=new JdbcTemplate(ds);
	}

	public List<Logins> retLogins() {
		String query="select * from logins";
		List<Logins> ll=jdbcTemplate.query(query, new LoginMapper());
		return ll;
	}

	public void insLogins(Logins ll) {
		String query="insert into logins values ('"+ll.getUsername()+"','"+ll.getPassword()+"')";
		jdbcTemplate.execute(query);
	}

	public void upsLogins(Logins ll) {
		String query="update logins set password=? where username=?";
		jdbcTemplate.update(query,ll.getPassword(),ll.getUsername());
	}

	public void delLogins(String uname) {
		String query="delete from logins where username=?";
		jdbcTemplate.update(query,uname);
	}

	public List<Books> retBooks() {
		String query="select * from books";
		List<Books> ll=jdbcTemplate.query(query, new BooksMapper());
		return ll;	
	}

	public void insBooks(Books bb) {
		String query="insert into books values ("+bb.getBid()+",'"+bb.getBname()+"','"+bb.getBauth()+"')";
		jdbcTemplate.execute(query);
	}

	public void upsBooks(Books bb) {
		String query="update books set bname=?,bauth=? where bid=?";
		jdbcTemplate.update(query,bb.getBname(),bb.getBauth(),bb.getBid());
	}

	public void delBooks(int bid) {
		String query="delete from books where bid=?";
		jdbcTemplate.update(query,bid);		
	}

}
