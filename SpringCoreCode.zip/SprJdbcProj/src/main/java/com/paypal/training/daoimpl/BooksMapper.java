package com.paypal.training.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.paypal.training.models.Books;

public class BooksMapper implements RowMapper<Books> {
	public Books mapRow(ResultSet rs, int rowNum) throws SQLException {
		Books bb=new Books();
		bb.setBid(rs.getInt(1));
		bb.setBname(rs.getString(2));
		bb.setBauth(rs.getString(3));
		return bb;
	}
}
