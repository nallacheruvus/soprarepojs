package com.paypal.training.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.paypal.training.daoimpl.LoginJDBCTemplate;
import com.paypal.training.models.Books;
import com.paypal.training.models.Logins;

public class MnCls {

	public static void main(String[] args) {

		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		LoginJDBCTemplate lTemplate=(LoginJDBCTemplate)ctx.getBean("loginJDBCTemplate");
//		Logins loa=new Logins();
//		loa.setUsername("Peter");
//		loa.setPassword("Wilde");
//		lTemplate.insLogins(loa);
//		lTemplate.upsLogins(loa);
//		lTemplate.delLogins("Peter");
//		List<Logins> ll=lTemplate.retLogins();
//		for(Logins l:ll) {
//			System.out.println(l.getUsername()+" "+l.getPassword());
//		}
		
		Books bb=new Books();
//		bb.setBid(6);
//		bb.setBname("History Of India In Letters");
//		bb.setBauth("Jawaharlal Nehru");
//		lTemplate.insBooks(bb);
//		lTemplate.upsBooks(bb);
		lTemplate.delBooks(6);
		List<Books> lb=lTemplate.retBooks();
		lb.forEach(n->System.out.println(n));
	
		
		
		
		
	}

}
