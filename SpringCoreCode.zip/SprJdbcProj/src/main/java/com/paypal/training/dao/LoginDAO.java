package com.paypal.training.dao;

import java.util.List;

import javax.sql.DataSource;

import com.paypal.training.models.Logins;

public interface LoginDAO {
	public void setDataSource(DataSource ds);
	public List<Logins> retLogins();
	public void insLogins(Logins ll);
	public void upsLogins(Logins ll);
	public void delLogins(String uname);	
}
