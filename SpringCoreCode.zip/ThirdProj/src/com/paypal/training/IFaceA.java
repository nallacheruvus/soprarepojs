package com.paypal.training;

@FunctionalInterface
public interface IFaceA {
	void prnTester();
}
