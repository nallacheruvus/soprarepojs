package com.paypal.training;

public class MnClsF {

	public static void main(String[] args)   {
		MyThread tha;
		try {
			tha = new MyThread();
			tha.setPriority(Thread.MAX_PRIORITY);
//		tha.sleep(1000);
//		Thread.sleep(1000);
//			tha.wait();
//				tha.interrupt();
				tha.run();
		} catch (IllegalMonitorStateException e) {
			System.out.println("Current thread is not parent to wait");
		}finally {
			System.out.println("Always execute");
		}
		
		AThread thb=new AThread();
//		thb.start();
		BThread thc=new BThread();
//		thc.run();
//		System.out.println("Hai there");
		
//		Thread[] aThr= {tha,thb,new Thread(thc)};
		
//		for(Thread t:aThr) {
//			t.start();
//		}
		
//		ThreadGroup group=new ThreadGroup("My Thread Group");
//		group.enumerate(aThr);
//		group.list();
//		System.out.println(group.activeCount());
		
		
		
		
	}

}
