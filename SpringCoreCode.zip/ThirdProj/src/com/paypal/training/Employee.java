package com.paypal.training;

public class Employee {
	private String ename;
	public String getEname() {
		return ename;
	}

	public Integer getAge() {
		return age;
	}

	public String getDesignation() {
		return designation;
	}

	private Integer age;
	private String designation;
	
	public Employee() {
	}
	
	public Employee(String a,Integer b,String c) {
		this.ename=a;
		this.age=b;
		this.designation=c;
	}
	
	@Override
	public String toString() {
		return this.ename+" "+this.age+" "+this.designation;
	}
}