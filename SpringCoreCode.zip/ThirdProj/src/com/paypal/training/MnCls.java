package com.paypal.training;

import java.util.Arrays;
import java.util.function.Consumer;

public class MnCls {

	
	
	public static void inHindi() {
		System.out.println("Kaise ho");
	}
	
	public static void inEnglish() {
		System.out.println("How are you");
	}
	
	public static void prnLogs() {
		for (int i = 0; i < 100; i++) {
			System.out.println("Log("+i+")="+Math.log(i));
		}
	}
	
	public void myTester() {
		for (int i = 1; i < 10; i++) {
			System.out.println("Sqrt("+i+")="+Math.sqrt(i));
		}
	}
	
	public static void main(String[] args) {
//		IFace face=MnCls::inHindi;
//		face.talk();
//		IFace face2=MnCls::inEnglish;
//		face2.talk();
//		IFace face3=MnCls::prnLogs;
//		face3.talk();
//		MnCls cls=new MnCls();
//		IFaceA face4=cls::myTester;
//		face4.prnTester();
		
		String[] arr= {"Ganesh","Krishna","Ali","Peter","Radhika"};
//		
		//The input to this foreach loop is an object which implements Consumer interface
		MyConsume con=new MyConsume();
		Arrays.asList(arr).forEach(con);
		Integer[] arr2= {21,32,43,54,65,76,98,90,900};
		Consumer<Integer> cona=new Consumer<Integer>() {
			@Override
			public void accept(Integer t) {
				if(t%2==0) {
					System.out.println(t);
				}
			}
		};
		Arrays.asList(arr2).forEach(cona);
		Double[] arr3= {21.2222,43.4444,54.555,65.666,76.7778};
//		Arrays.asList(arr3).forEach(new Consumer<Double>() {
//			@Override
//			public void accept(Double t) {
//				System.out.println(t);
//			}
//		});
		Arrays.asList(arr2).forEach(n->{if(n%2!=0) {System.out.println(n);}});
//		Arrays.asList(arr3).forEach(System.out::println);
		
		
	}

}
