package com.paypal.training;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MnClsH {

	public static void main(String[] args) {

		List<SalEmployee> lsSalEmp=new ArrayList<SalEmployee>();
		lsSalEmp.add(new SalEmployee("Gurucharan", 12000, 1000, 500));
		lsSalEmp.add(new SalEmployee("Manikprabhu", 17000, 5000, 2500));
		lsSalEmp.add(new SalEmployee("Dharamkaran", 20000, 4000, 1500));
		lsSalEmp.add(new SalEmployee("Jagjivan", 22000, 10000, 500));
		lsSalEmp.add(new SalEmployee("Rajiv Ranjan", 10000, 11000, 1500));
		ExecutorService executor=Executors.newFixedThreadPool(5);
		List<Future<Float>> resAvgSals=null;
		try {
			resAvgSals=executor.invokeAll(lsSalEmp);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for(Future<Float> f:resAvgSals) {
			try {
				System.out.println(f.get());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}
		}
		
	}

}
