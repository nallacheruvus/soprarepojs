package com.paypal.training;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class MnClsI {
	public static void main(String[] args) {
		int procCount=Runtime.getRuntime().availableProcessors();
		System.out.println("The no of processors on the system is "+procCount);
		ForkJoinPool fjPool=new ForkJoinPool(procCount);
		int y=9;
		ForkTester tester=new ForkTester(0,y);
		Integer ii=fjPool.invoke(tester);
		System.out.println("Before Await of termination "+fjPool.isTerminating());
		System.out.println(" Awaiting Quiesence "+fjPool.awaitQuiescence(2, TimeUnit.SECONDS));
		try {
			fjPool.awaitTermination(4, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("The result of invocation is "+ii);
	}
}
