package com.paypal.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import java.util.stream.Stream;


public class MnClsA {

	public static void main(String[] args) {

		ArrayList<Integer> al=new ArrayList<Integer>();
//		Vector<Integer> al=new Vector<Integer>();
		for (int i = 1; i <= 100; i++) {
			al.add(i);
		}
//		al.forEach(n->System.out.println(n));
		
//		Stream<Integer> stra=al.stream();
		Stream<Integer> stra=al.parallelStream();
//		stra.forEach(n->System.out.println(n));
//		stra.filter(n->(n%2==0)).forEach(n->System.out.println(n));
		String[] arr2= {"Gangapur","Maithili","Ganganagar","Ramdevpur","Jahnavi","ganga","Jhelum","Miryalguda"};
		//Filtername with G
		Stream<String> atrb=Arrays.asList(arr2).stream();
		//On,ly names with G or g
		//atrb.filter(n->n.startsWith("G")||n.startsWith("g")).forEach(n->System.out.println(n));
//		atrb.filter(n->!(n.startsWith("G")||n.startsWith("g"))).forEach(n->System.out.println(n));
		//Only names which dont start with g or G
		//String whose length is not more than five
//		atrb.filter(n->n.length()<=5).forEach(n->System.out.println(n));
		atrb.map(n->retRev(n.toUpperCase())).forEach(System.out::println);
		
	}
	
	static String retRev(String a) {
		return new StringBuffer(a).reverse().toString();
	}

}
