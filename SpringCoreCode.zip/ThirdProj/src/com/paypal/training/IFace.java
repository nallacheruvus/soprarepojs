package com.paypal.training;

@FunctionalInterface
public interface IFace {
	void talk();
}
