package com.paypal.training;

public class CutomThr extends Thread {
	
	private int ii;
	
	
	private String tName;
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	private String[] tMsg;
	public String[] gettMsg() {
		return tMsg;
	}
	public void settMsg(String[] tMsg) {
		this.tMsg = tMsg;
	}
	public CutomThr() {
		System.out.println("Starting the main thread which will span child worker threads!");
	}
	
	@Override
	public void run() {
		//Spawning Threads
		Thread[] aThr=new Thread[this.ii];
		for (int i = 0; i < aThr.length; i++) {
			aThr[i]=new Thread(new Runnable() {
				@Override
				public void run() {
					System.out.println("Currently running Child Thread ");
				}
			});
			aThr[i].setName(tName);
			System.out.println("Setting the message "+i+" "+this.tMsg[i]);
			aThr[i].start();
		}
		
	}
	public int getIi() {
		return ii;
	}
	public void setIi(int ii) {
		this.ii = ii;
	}

}