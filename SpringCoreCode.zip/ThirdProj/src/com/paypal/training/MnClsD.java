package com.paypal.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MnClsD {
	
	static ArrayList<Employee> retList(){
		String[] arr1= {"Ganesh","Ali","Peter","Gaurav","Kumar"};
		Integer[] arr2= {32,43,21,19,76};
		String[] arr3= {"Manager","Programmer","Systems Analyst","Data Scientist","Machine Learning Expert"};
		ArrayList<Employee> ae=new ArrayList<Employee>();
		for (int i = 0; i < arr3.length; i++) {
			Employee emp=new Employee(arr1[i], arr2[i], arr3[i]);
			ae.add(emp);
		}
		return ae;
	}
	
	public static void main(String[] args) {
		List<Employee> le=retList();
		Stream<Employee> strEmp=le.stream();
		//Printing all employees
//		strEmp.forEach(System.out::println);
		//Printing employees whose age is less than 20
//		strEmp.filter(n->n.getAge()<=20).forEach(n->System.out.println(n));
//		strEmp.filter(n->(n.getDesignation().equals("Manager")||n.getDesignation().equals("Data Scientist"))).forEach(n->System.out.println(n));
//		strEmp.filter(n->(n.getDesignation().equals("Manager")||n.getDesignation().equals("Data Scientist"))).forEach(n->System.out.println(n.getEname()));
//		strEmp.filter(n->(n.getDesignation().equals("Manager")||n.getDesignation().equals("Data Scientist"))).map(n->n.getEname()).forEach(System.out::println);
//		strEmp.forEachOrdered(n->System.out.println(n));
//		List ll= strEmp.map(n->n.getAge()).collect(Collectors.toList());
//		ll.forEach(System.out::println);
//		Set setNames= strEmp.map(n->n.getEname()).collect(Collectors.toSet());
//		setNames.forEach(n->System.out.println(n));
//		double dd=strEmp.map(n->n.getAge()).collect(Collectors.averagingDouble(n->n)).doubleValue();
//		System.out.println(dd);
//		long y=strEmp.count();
//		System.out.println(y);
//		strEmp.distinct().forEach(System.out::print);
//		System.out.println(strEmp.findFirst().get().toString());
//		strEmp.iterator().forEachRemaining(n->System.out.println(n));
//		strEmp.limit(2).forEach(n->System.out.println(n));
//		Object[] arra=strEmp.toArray();
		
//		Optional<Integer> opt=Optional.of(21);
//	
//		if(opt.empty() != null) {
//			System.out.println(opt.get());
//		}else {
//			
//		}
		
		Function<Integer, Double> ff=f->Math.sqrt(f);
		Arrays.asList(new Integer[] {10,20,4,5,6}).stream().map(ff).forEach(System.out::println);
		
		//Lazy Loading
		
//		System.out.println(ff.apply(10).doubleValue());
		
//		Function<String, String> gg=f->f.toUpperCase();
//		System.out.println(gg.apply("krishna").toString());
//		
//		BiFunction<Integer, Integer, Double> hh=(f,k)->Math.pow(f, k);
//		System.out.println(hh.apply(2, 3).intValue());
//		
//		Predicate<Integer> pp=i->i>2;
//		Predicate<Integer> pq=i->i%2==0;
//		Integer[] arr4= {1,2,2,32,4};
//		Arrays.asList(arr4).stream().filter(pq).distinct().forEach(n->System.out.println(n));
		
		int a=100;
//		tesFun(ff, a);
		Arrays.asList(new Integer[] {2,3,4,5,7}).forEach(n->tesFun(ff, n));
		
		Date dt=new Date();
		System.out.println(dt.toGMTString());
		
		Calendar cal=Calendar.getInstance();
		System.out.println(cal.getTime().toGMTString());
		
		
		
		
	}
	
	static void tesFun(Function<Integer, Double> aa, Integer a) {
		System.out.println(aa.apply(a));
	}
	
	
	
}
