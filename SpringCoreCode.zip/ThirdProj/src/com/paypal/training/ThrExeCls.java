package com.paypal.training;

public class ThrExeCls {

	public static void main(String[] args) {
		Runnable thrA = new Runnable() {
			@Override
			public void run() {
				for (int i = 0; i < 10; i++) {
					System.out.println(i + 1);
				}
			}
		};
		thrA.run();
		new Runnable() {
			@Override
			public void run() {
				System.out.println("Self starting thread");
			}
		}.run();
		Thread thrB = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Another way of printing from thread");
			}
		});
		thrB.setDaemon(true);
		thrB.setName("Gargoyle-A");
		System.out.println("***"+thrB.getName());
		thrB.start();
		Runnable thrC = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Yet Another way of printing from thread");
			}
		});
		thrC.run();
		new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Running thread is interesting");
				
			}
		}).start();	
	}
}
