package com.paypal.training;

import java.util.concurrent.Callable;

public class SalEmployee implements Callable<Float> {
	private String name;
	private Integer gross;
	private Integer DA;
	private Integer HRA;
	
	
	public SalEmployee() {
		// TODO Auto-generated constructor stub
	}
	
	public SalEmployee(String a,Integer g,Integer d,Integer h) {
		this.name=a;
		this.gross=g;
		this.DA=d;
		this.HRA=h;
	}

	@Override
	public Float call() throws Exception {
		float avgSal=(this.gross+this.HRA+this.DA)/3.0f;
		return avgSal;
	}
}
