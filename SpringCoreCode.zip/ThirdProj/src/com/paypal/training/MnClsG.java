package com.paypal.training;

public class MnClsG {

	public static void main(String[] args) {

		//Parametrized Thread in JAva
		String[] arr= {"First Msg","Sec Msg","Third Msg","Fourth Msg","Fifth Msg","First Msg","Sec Msg","Third Msg","Fourth Msg","Fifth Msg"};
		CutomThr thrA=new CutomThr();
		thrA.settName("My Main Thread");
		thrA.setIi(5);
		thrA.settMsg(arr);
		thrA.start();
		
		
		
	}

}
