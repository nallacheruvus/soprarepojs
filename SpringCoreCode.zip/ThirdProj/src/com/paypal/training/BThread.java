package com.paypal.training;

public class BThread implements Runnable {
	@Override
	public void run() {
		for (int i = 0; i < 360; i+=45) {
			System.out.println("^^^^^^Sin("+i+")="+Math.sin(i));
		}
	}
}
