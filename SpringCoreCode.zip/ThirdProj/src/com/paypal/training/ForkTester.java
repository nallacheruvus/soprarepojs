package com.paypal.training;

import java.util.concurrent.RecursiveTask;

public class ForkTester extends RecursiveTask<Integer> {
	
	private int startNum;
	private int endNum;

	
	public ForkTester() {
		// TODO Auto-generated constructor stub
	}
	
	public ForkTester(int b,int c) {
		this.startNum=b;
		this.endNum=c;
	}
	
	@Override
	protected Integer compute() {
		Integer sNum=0;
		for(int i=startNum;i<endNum;i++) {
			sNum+=i;
		}
		System.out.println("*********"+sNum);
		int avg=(startNum+endNum)/2;
		return (sNum);
	}

}
