package com.paypal.training;

public class AThread extends Thread {
	
	public AThread() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("Sqrt("+i+")="+Math.sqrt(i));
		}
	}

}
