package com.paypal.training.spranno.cls;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.paypal.training.spranno.mods.Logins;
import com.paypal.training.spranno.repos.LoginsRepository;

public class MnClsLogins {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		ctx.scan("com.paypal.training.spranno.repos");
		ctx.refresh();
		LoginsRepository repo=ctx.getBean(LoginsRepository.class);
//		Logins ll=(Logins)repo.retrieve(2);
//		System.out.println(ll);
//		Logins la=new Logins();
//		la.setUsername("Kumar Gandharva");
//		la.setPassword("gandharva");
//		repo.store(la);
		ctx.close();
	}
}
