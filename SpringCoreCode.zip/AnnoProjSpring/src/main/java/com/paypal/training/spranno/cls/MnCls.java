package com.paypal.training.spranno.cls;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.paypal.training.spranno.mods.Books;
import com.paypal.training.spranno.repos.BooksRepository;

public class MnCls {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		ctx.scan("com.paypal.training.spranno.repos");
		ctx.refresh();
		BooksRepository repo=ctx.getBean(BooksRepository.class);
		int[] arr1= {1,2,3,4,5};
		String[] arr2= {"Ramayan","Mahabharat","Romeo Juliet","God Of Small Things","Krishna Key"};
		String[] arr3= {"Valmiki","Vyas","Shakespere","Arundhati Roy","Ashwini Sanghi"};
		for (int i = 0; i < arr3.length; i++) {
			Books bb=new Books();
			bb.setBid(arr1[i]);
			bb.setBname(arr2[i]);
			bb.setBauth(arr3[i]);
			repo.store(bb);
		}
		Books book=(Books)repo.retrieve(1);
		System.out.println(book);
		repo.delete(1);
		Books booka=(Books)repo.retrieve(1);
		System.out.println(booka);

		ctx.close();
	}
}
