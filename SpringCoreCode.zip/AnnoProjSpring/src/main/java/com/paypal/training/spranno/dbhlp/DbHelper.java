package com.paypal.training.spranno.dbhlp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.paypal.training.spranno.mods.Logins;

public class DbHelper {
	static Connection conn = null;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	Map<Integer, Logins> map = new HashMap<Integer, Logins>();

	public Map<Integer, Logins> retMap() {
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from logins");
			int i = 1;
			while (rs.next()) {
				Logins ll = new Logins();
				ll.setUsername(rs.getString(1));
				ll.setPassword(rs.getString(2));
				map.put(i, ll);
				i++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return map;
	}

	public void insRec(Logins ll) {
		try {
			PreparedStatement ps = conn.prepareStatement("insert into logins values(?,?)");
			ps.setString(1, ll.getUsername());
			ps.setString(2, ll.getPassword());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
