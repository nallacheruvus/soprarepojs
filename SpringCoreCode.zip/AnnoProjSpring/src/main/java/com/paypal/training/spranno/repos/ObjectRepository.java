package com.paypal.training.spranno.repos;

public interface ObjectRepository<T> {
	public void store(T t);
	public T retrieve(int a);
	public void delete(int a);
}
