package com.paypal.training.spranno.repos;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.paypal.training.spranno.mods.Books;

@Configuration
@Repository
public class BooksRepository implements ObjectRepository<Books> {
	private Map<Integer, Books> mrep;
	public BooksRepository() {
		this.mrep=new HashMap<Integer, Books>();
	}
	public void store(Books t) {
		this.mrep.put(t.getBid(), t);
	}
	public Books retrieve(int a) {
		return mrep.get(a);
	}
	public void delete(int a) {
		mrep.remove(a);
	}
}