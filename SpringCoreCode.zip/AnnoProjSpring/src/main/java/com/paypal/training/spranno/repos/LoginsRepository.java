package com.paypal.training.spranno.repos;

import java.util.Map;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.paypal.training.spranno.dbhlp.DbHelper;
import com.paypal.training.spranno.mods.Logins;
@Configuration
@Repository
public class LoginsRepository implements ObjectRepository<Logins> {
	DbHelper helper = new DbHelper();
	Map<Integer, Logins> map = helper.retMap();

	public void store(Logins t) {
		helper.insRec(t);
	}

	public Logins retrieve(int a) {
		return map.get(a);
	}

	public void delete(int a) {
		// TODO Auto-generated method stub
	}

}
