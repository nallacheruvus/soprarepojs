package com.paypal.training.cls;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MnCls {
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		ClassA aa=(ClassA)ctx.getBean("ClassA");
		aa.prn();
		aa.display();
	}
}
