package com.paypal.training.cls;

public class ClassB {
	public ClassB() {
		System.out.println("ClassB is Created");
	}
	
	public void prnTester() {
		System.out.println("From ClassB Method");
	}
}
