package com.paypal.training.cls;

public class ClassA {
	ClassB b;
	
	public ClassB getB() {
		return b;
	}

	public void setB(ClassB b) {
		this.b = b;
	}

	void prn() {
		System.out.println("Called from class a");
	}
	
	void display() {
		prn();
		b.prnTester();
	}
	
	public ClassA() {
		System.out.println("Constructor of class called object created");
	}
}
