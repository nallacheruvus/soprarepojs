package com.paypal.training.spr.cls;

import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MnCls {
	public static void main(String[] args) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext(MyConfigCls.class);
		Books bb=(Books)ctx.getBean(Books.class);
		System.out.println(bb.getBname()+" "+bb.getBauth());
		Schools sc=(Schools)ctx.getBean(Schools.class);
		System.out.println(sc.getSname());
		System.out.println(Arrays.toString(sc.getMedium()));
	}
}
