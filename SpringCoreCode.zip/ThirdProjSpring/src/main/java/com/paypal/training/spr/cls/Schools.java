package com.paypal.training.spr.cls;

public class Schools {
	private String sname;
	private String medium[];
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String[] getMedium() {
		return medium;
	}
	public void setMedium(String[] medium) {
		this.medium = medium;
	}
}
