package com.paypal.training.spr.cls;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConfigCls {
	@Bean
	public Books retBooks() {
		Books bb=new Books();
		bb.setBname("Pelican Brief");
		bb.setBauth("John Grisham");
		return bb;
	}
	
	
	@Bean
	public Schools retSchools() {
		Schools sc=new Schools();
		String[] arr= {"Engish","Hindi","Urdu","Punjabi","Marathi"};
		sc.setSname("Villa Mary Convent");
		sc.setMedium(arr);
		return sc;
	}
}
