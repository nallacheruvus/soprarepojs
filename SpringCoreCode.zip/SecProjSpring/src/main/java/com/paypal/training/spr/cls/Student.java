package com.paypal.training.spr.cls;

import org.springframework.beans.factory.annotation.Value;

public class Student {
	
	
	private String jester;
	
	public Student() {

	}
	
	private College coll;
	private String sname;
	public College getColl() {
		return coll;
	}
	public void setColl(College coll) {
		this.coll = coll;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSbranch() {
		return sbranch;
	}
	public void setSbranch(String sbranch) {
		this.sbranch = sbranch;
	}
	public String getJester() {
		return jester;
	}
	

	private String sbranch;
}
