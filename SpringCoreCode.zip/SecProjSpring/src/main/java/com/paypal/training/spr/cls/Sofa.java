package com.paypal.training.spr.cls;

public class Sofa {
	private String scolor;
	private String stype;
	public String getScolor() {
		return scolor;
	}
	public void setScolor(String scolor) {
		this.scolor = scolor;
	}
	public String getStype() {
		return stype;
	}
	public void setStype(String stype) {
		this.stype = stype;
	}
	
	@Override
	public String toString() {
		return this.stype+" "+this.scolor;
	}
}
