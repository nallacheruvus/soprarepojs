package com.paypal.training.spr.cls;

public class TruckEngine extends Engine {
	
	private String brand;

	@Override
	public String retDetsOfEng() {
		return this.getEname()+" "+this.getBrand()+" "+this.getEbrand()+" "+this.getRpms();
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

}
