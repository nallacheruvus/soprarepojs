package com.paypal.training.spr.cls;

public class Furniture {
	
	private Chair chair;
	private Sofa sofa;
	
	public Furniture() {
		// TODO Auto-generated constructor stub
	}
	
	public Furniture(Chair ch,Sofa so) {
		this.chair=ch;
		this.sofa=so;
	}
	
	@Override
	public String toString() {
		String jj=this.sofa.toString()+" "+this.chair.toString();
		return jj;
	}

}
