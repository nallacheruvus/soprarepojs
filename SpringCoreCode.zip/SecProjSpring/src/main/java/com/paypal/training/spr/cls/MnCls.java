package com.paypal.training.spr.cls;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MnCls {

	public static void main(String[] args) {
		ApplicationContext fact=new ClassPathXmlApplicationContext("applicationContext.xml");
		TruckEngine te=(TruckEngine)fact.getBean("teng");
		System.out.println(te.retDetsOfEng());
		Student stda=(Student)fact.getBean("stda");
		System.out.println(stda.getSname()+" "+stda.getSbranch());
		College cc=(College)stda.getColl();
//		Scanner scan=new Scanner(System.in);
//		System.out.println("Enter New Address");
//		String ss=scan.nextLine();	
//		cc.setCaddress(ss);
		System.out.println(stda.getJester());
		System.out.println(cc.getCname()+" "+cc.getCaddress());
		Furniture furn=(Furniture)fact.getBean("furnHall");
		System.out.println(furn);
		
		
		
		
	}

}
