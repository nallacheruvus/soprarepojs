package com.paypal.training.spr.cls;

public class Chair {
	private String ctype;
	public String getCtype() {
		return ctype;
	}
	public void setCtype(String ctype) {
		this.ctype = ctype;
	}
	public String getCmat() {
		return cmat;
	}
	public void setCmat(String cmat) {
		this.cmat = cmat;
	}
	private String cmat;
	
	@Override
	public String toString() {
		return this.cmat+" "+this.ctype;
	}
}
