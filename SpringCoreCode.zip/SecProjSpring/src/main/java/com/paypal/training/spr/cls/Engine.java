package com.paypal.training.spr.cls;

public abstract class Engine {
	private int rpms;
	private String ename;
	private String ebrand;
	public int getRpms() {
		return rpms;
	}
	public void setRpms(int rpms) {
		this.rpms = rpms;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEbrand() {
		return ebrand;
	}
	public void setEbrand(String ebrand) {
		this.ebrand = ebrand;
	}
	
	public abstract String retDetsOfEng();
	
}
