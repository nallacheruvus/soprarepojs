package com.paypal.spr.cls;

public class Persons {

	private int pid;
	private String pname;
	private String pemail;

	public Persons() {
	}

	public Persons(int i, String j, String g) {
		this.pid = i;
		this.pname = j;
		this.pemail = g;
	}

	@Override
	public String toString() {
		String op = "Id:" + this.pid + " Name:" + this.pname + " Email:" + this.pemail;
		return op;
	}

}
