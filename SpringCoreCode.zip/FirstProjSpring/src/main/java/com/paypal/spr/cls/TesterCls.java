package com.paypal.spr.cls;

public class TesterCls {
	public String retRev(String j) {
		return new StringBuffer(j).reverse().toString();
	}
}
