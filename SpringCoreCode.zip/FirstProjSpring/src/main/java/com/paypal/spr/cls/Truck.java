package com.paypal.spr.cls;

public class Truck extends Automobile {
	private String tmake;
	public String getTmake() {
		return tmake;
	}
	public void setTmake(String tmake) {
		this.tmake = tmake;
	}
	@Override
	public String toString() {
		return this.getAname()+" "+this.getAbrand()+" "+this.getTmake()+" "+this.getAid();
	}
}
