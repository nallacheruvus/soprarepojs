package com.paypal.spr.cls;

import java.awt.FlowLayout;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanTester {
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		TesterCls cls=(TesterCls)ctx.getBean("clsb");
		System.out.println(cls.retRev("Satish"));
		BankAccount ba=(BankAccount)ctx.getBean("bActA");
		System.out.println(ba.getBid()+" "+ba.getBname()+" "+ba.getAname());
		BankAccount bb=(BankAccount)ctx.getBean("bActA");
		bb.setAname("Manik");
		System.out.println(bb.getBid()+" "+bb.getBname()+" "+bb.getAname());


		
		Persons pp=(Persons)ctx.getBean("suresh");
		System.out.println(pp);
		Persons ppa=(Persons)ctx.getBean("sarvesh");
		System.out.println(ppa);
		Truck tck=(Truck)ctx.getBean("truckb");
		System.out.println(tck);
		
		
		
		
		
		
	}

}
