package com.paypal.spr.cls;

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyFrame extends JFrame {

	
	public MyFrame() {

		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		BankAccount ba=(BankAccount)ctx.getBean("bActA");
		Container cont=getContentPane();
		JButton button=new JButton();
		button.setText(String.valueOf(ba.getBid())+" "+ba.getAname()+" "+ba.getBname());
		cont.add(button);
		
	
	
	
	}
	
	
}
