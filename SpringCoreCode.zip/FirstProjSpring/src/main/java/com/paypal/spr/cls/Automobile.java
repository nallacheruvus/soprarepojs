package com.paypal.spr.cls;

public class Automobile {
	private int aid;
	private String aname;
	private String abrand;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getAbrand() {
		return abrand;
	}
	public void setAbrand(String abrand) {
		this.abrand = abrand;
	}
	
}
