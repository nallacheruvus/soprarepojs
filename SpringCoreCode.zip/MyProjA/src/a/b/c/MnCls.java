package a.b.c;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class MnCls {

	public static void main(String[] args) {

		
//		ACls<Integer,Integer> aa=new ACls<Integer,Integer>();
//		aa.setT(1000);
//		aa.setU(1500);
//		System.out.println(aa.getT());
//		System.out.println(aa.getU());
//		aa.prnRes();
		
		ArrayList<BankAccount> ab=new ArrayList<BankAccount>();
		ab.add(new BankAccount("Sudhir", "Bank Of New york", 210, 320, 440));
		ab.add(new BankAccount("Sashi", "Bank Of Punjab", 212, 332, 444));
		ab.add(new BankAccount("Sumadhur", "Bank Of New york", 215, 325, 445));
		ab.add(new BankAccount("Sandeep", "Bank Of New york", 521, 532, 544));
		
		ExecutorService service=Executors.newFixedThreadPool(4);
		List<Future<Float>> results=null;
		try {
			results=service.invokeAll(ab);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		for(Future<Float> e:results) {
			try {
				System.out.println(e.get());
			} catch (InterruptedException | ExecutionException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}

}
