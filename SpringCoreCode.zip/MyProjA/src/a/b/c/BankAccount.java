package a.b.c;

import java.util.concurrent.Callable;

public class BankAccount implements Callable<Float> {

	private String name;
	private String bname;
	Integer actbala;
	Integer actbalb;
	Integer actbalc;
	
	public BankAccount(String a,String b,Integer p,Integer q,Integer r) {
		this.name=a;
		this.bname=b;
		this.actbala=p;
		this.actbalb=q;
		this.actbalc=r;
	}
	
	@Override
	public Float call() throws Exception {
		Float aa=(Float)(this.actbala+this.actbalb+this.actbalc/3.0f);
		return aa;
	}
}
