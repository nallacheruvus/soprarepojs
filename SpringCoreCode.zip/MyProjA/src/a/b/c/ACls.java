package a.b.c;

public class ACls<T,U> {

	
	private T t;
	
	private U u;

	public U getU() {
		return u;
	}

	public void setU(U u) {
		this.u = u;
	}

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}
	
	public void prnRes() {
		T tt=this.t;
		U uu=this.u;
		if(tt instanceof Integer && uu instanceof Integer) {
			Integer a=(Integer)tt;
			Integer b=(Integer)uu;
			System.out.println(a+b);
		}
	}
	
}
