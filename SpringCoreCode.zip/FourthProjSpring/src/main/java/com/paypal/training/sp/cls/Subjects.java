package com.paypal.training.sp.cls;

import java.util.ArrayList;

public class Subjects {
	private ArrayList<String> subjects;
	private String department;
	public ArrayList<String> getSubjects() {
		return subjects;
	}
	public void setSubjects(ArrayList<String> subjects) {
		this.subjects = subjects;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
}
