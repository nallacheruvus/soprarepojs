package com.paypal.training.sp.cls;

import java.util.Set;

public class MarksAggregator {
	private String sname;
	private Set<Integer> smarks;
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Set<Integer> getSmarks() {
		return smarks;
	}
	public void setSmarks(Set<Integer> smarks) {
		this.smarks = smarks;
	}
}
