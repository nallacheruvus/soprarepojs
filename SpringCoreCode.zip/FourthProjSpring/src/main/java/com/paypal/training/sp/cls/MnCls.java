package com.paypal.training.sp.cls;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class MnCls {

	public static void main(String[] args) {

		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		University univ=(University)ctx.getBean("univa");
//		System.out.println(univ.getUname());
		//Arrays.asList(univ.getDepartments()).stream().forEach(n->System.out.println(n));
//		List<String> ls=Arrays.asList(univ.getDepartments());
//		Iterator<String> itr=ls.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}
		
//		Subjects subs=(Subjects)ctx.getBean("subject");
//		System.out.println(subs.getDepartment());
//		List<String> ls=subs.getSubjects();
//		ls.iterator().forEachRemaining(n->System.out.println(n));
//		ls.listIterator().forEachRemaining(n->System.out.println(n));
//		ls.stream().forEach(n->System.out.println("\t\t-"+n));
		
		
//		MarksAggregator agg=(MarksAggregator)ctx.getBean("aggreg");
//		System.out.println(agg.getSname());
//		Set<Integer> ss=agg.getSmarks();
//		ss.stream().forEach(System.out::println);
//		ss.iterator().forEachRemaining(System.out::println);
//		for(Object a:ss) {
//			System.out.println(a);
//		}
		
//		LibraryUniv univa=(LibraryUniv)ctx.getBean("libuniv");
//		System.out.println(univa.getUname());
//		Map<Integer, String> map=univa.getSecSubMap();
////		map.entrySet().forEach(n->System.out.println(n.getKey()+" "+n.getValue()));
//		map.forEach((a,b)->System.out.println(a+" "+b));//BiConsumer
//		Iterator<Integer> itr=map.keySet().iterator();
//		while(itr.hasNext()) {
//			Integer ii=itr.next();
//			System.out.println(ii+" "+map.get(ii));
//		}
		
		
		ExpressionParser parser = new SpelExpressionParser();  
		  
		Expression exp = parser.parseExpression("'Hello SPEL'");  
		String message = (String) exp.getValue();  
		System.out.println(message);  
		
		
		
	}

}
