package com.paypal.training.sp.cls;

import java.util.Map;

public class LibraryUniv {
	private String uname;
	private Map<Integer, String> secSubMap;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public Map<Integer, String> getSecSubMap() {
		return secSubMap;
	}
	public void setSecSubMap(Map<Integer, String> secSubMap) {
		this.secSubMap = secSubMap;
	}
}
