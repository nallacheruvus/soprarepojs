package com.sat.cls;

import java.util.Stack;

public class StackCls {
	public static void prnStack() {
		String[] arr= {"Krishna","Krishnapriya","Radhika","Radha","Raseswari"};
		Stack stk=new Stack();
		//Writing to stack
		for(String j:arr) {
			stk.push(j);
		}
		//Reading from stack
		while(stk.size()>0) {
			System.out.println(stk.pop());
		}
	}
}
