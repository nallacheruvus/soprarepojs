package com.sat.cls;

import java.util.LinkedList;

public class LListCls {

	public static void llList() {
		String[] arr= {"Einstein","Newton","Ramanujam","Bose","Aryabhatta"};
		//Ensuring type safety at design time in order to avoid compile time errors is called Generics
		LinkedList<String> lls=new LinkedList<String>();
		//Writing to linkedlist
		for(String j:arr) {
//			lls.addFirst(j);//Stack
			lls.addLast(j);//Queue
		}
		//reading from linkedlist
		for(Object j:lls) {
			System.out.println(j);
		}
		Integer[] arr2= {21,32,43,54,65,76};
		LinkedList<Integer> lla=new LinkedList<Integer>();
		//writing
		for(Integer i:arr2) {
			lla.add(i);
		}
		//reading
		for(Object a:lla) {
			System.out.println(a);
		}
	}
}
