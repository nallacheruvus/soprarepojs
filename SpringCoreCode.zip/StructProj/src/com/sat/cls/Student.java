package com.sat.cls;

public class Student {
	private Integer sid;
	private String sname;
	private String semail;
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	
	@Override
	public String toString() {
		String form=String.format("Id:%d\nName:%s\nEmail:%s", this.sid,this.sname,this.semail);
		return form;
	}
}
