package com.sat.cls;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetFamilyCls {

	static final String[] arr = { "Mathematics", "Mathematics", "Mathematics", "Nuclear Physics", "Plant Botany",
			"Genetics", "Genetics", "Genetics", "Genetics", "Geophysics" };
	static final Integer[] arr2 = { 1002, 2, 3, 3, 3, 100, 4, 4, 50, 70, 50, 60, 60, 60, 70, 70, 800, 80, 8, 90, 90, 9,
			9 };

	public static void prnHashset() {
		HashSet<Integer> hs = new HashSet<Integer>();
		System.out.println("***" + arr2.length);
		// Writing to hashset
		for (Integer a : arr2) {
			hs.add(a);
		}
		System.out.println("***" + hs.size());
		// read from hashset
		for (Object j : hs) {
			System.out.println(j);
		}
	}

	/**
	 * First removes the duplicates then creates an linkedlist
	 */
	public static void prnLinHasSet() {
		LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
		// writing to lhs
		for (Integer i : arr2) {
			lhs.add(i);
		}
		// reading from lhs
		for (Object a : lhs) {
			System.out.println(a);
		}
	}

	
	/**
	 * Tree Set class which removes duplicates and sorts the set
	 */
	public static void prnTreeSe() {
		TreeSet<Integer> ts = new TreeSet<Integer>();
		// writing to lhs
		for (Integer i : arr2) {
			ts.add(i);
		}
		// reading from lhs
		for (Object a : ts) {
			System.out.println(a);
		}
	}

}
