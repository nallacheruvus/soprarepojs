package com.sat.cls;

import java.util.ArrayList;
import java.util.Vector;

public class VectorCls {
	/**
	 * Returns a vector of added values
	 */
	public static void retVec() {
		String[] arr= {"Einstein","Newton","Ramanujam","Bose","Aryabhatta"};
		Vector vec=new Vector();//Thread safe
		//Writing to vector
		for(String j:arr) {
			vec.add(j);//Boxing
		}
		//Read from vector
		for(Object a:vec) {
			System.out.println(a);//Unboxing
		}
	}

	/***
	 * Returns an array list 
	 */
	public static void retAList() {
		String[] arr= {"Einstein","Newton","Ramanujam","Bose","Aryabhatta"};
		ArrayList list=new ArrayList();
		//Writing to arraylist
		for (int i = 0; i < arr.length; i++) {
			list.add(arr[i]);
		}
		list.add(21);
		list.add(true);
		list.add(21.333f);
		//reading 
		for(Object a:list) {
			System.out.println(a);
		}
	}
}