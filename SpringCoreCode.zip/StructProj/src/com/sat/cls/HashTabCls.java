package com.sat.cls;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class HashTabCls {

	/**
	 * Hashtable for displaying keys and values
	 */
	public static void retHashTab() {
		Hashtable<Integer, String> ht=new Hashtable<Integer, String>();
		Integer[] arr1= {101,202,3030,404,505};
		String[] arr2= {"Maths","Geology","Geochemistry","Statistics","Nuclear Physics"};
		//Write
		for (int i = 0; i < arr2.length; i++) {
			ht.put(arr1[i], arr2[i]);
		}
		//Read
//		for(Entry<Integer, String> a:ht.entrySet()) {
//			System.out.println(a.getKey()+" "+a.getValue());
//		}
		Set<Entry<Integer, String>> en=ht.entrySet();
		for(Entry e:en) {
			System.out.println(e.getKey()+" "+e.getValue());
		}
	}
	
	/***
	 * Printing and writing elements into hashmap
	 */
	public static void prnHashMap() {
		Integer[] arr1= {101,202,3030,404,505};
		String[] arr2= {"Maths","Geology","Geochemistry","Statistics","Nuclear Physics"};
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		//Writing to hashmap
		for (int i = 0; i < arr2.length; i++) {
			hm.put(arr1[i], arr2[i]);
		}
		
		Set<Entry<Integer, String>> en=hm.entrySet();
		for(Entry e:en) {
			System.out.println(e.getKey()+" "+e.getValue());
		}
	}
	
	/***
	 * Printing and writing to a linked hashmap
	 */
	public static void prnLinkedHashMap() {
		Integer[] arr1= {101,202,3030,404,505};
		String[] arr2= {"Maths","Geology","Geochemistry","Statistics","Nuclear Physics"};
		LinkedHashMap<Integer, String> hm=new LinkedHashMap<Integer, String>();
		//Writing to hashmap
		for (int i = 0; i < arr2.length; i++) {
			hm.put(arr1[i], arr2[i]);
		}
		//reading
		Set<Entry<Integer, String>> en=hm.entrySet();
		for(Entry e:en) {
			System.out.println(e.getKey()+" "+e.getValue());
		}
	}
	
	public static void prnTreeMap() {
		Integer[] arr1= {101,202,3030,404,505};
		String[] arr2= {"Maths","Geology","Geochemistry","Statistics","Nuclear Physics"};
		TreeMap<Integer, String> hm=new TreeMap<Integer, String>();
		//Writing to Treemap
		for (int i = 0; i < arr2.length; i++) {
			hm.put(arr1[i], arr2[i]);
		}
//		Set<Entry<Integer, String>> en=hm.entrySet();
//		for(Entry e:en) {
//			System.out.println(e.getKey()+" "+e.getValue());
//		}
		Set set=hm.keySet();
		for(Object i:set) {
			System.out.println(i+" "+hm.get(i));
		}
	}
}
