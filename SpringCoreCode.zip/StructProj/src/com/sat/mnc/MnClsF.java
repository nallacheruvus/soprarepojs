package com.sat.mnc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import com.sat.cls.Student;

public class MnClsF {

	public static void main(String[] args) {

		Integer[] arr1= {1,2,3,4,5};
		String arr2[]= {"Sunita","Josh","Hussain","Menaka","Vardhan"};
		String arr3[]={"sunita@yahoo.com","josh@yahoo.com","Hussain@yahoo.com","Menaka@yahoo.com","vardhan@yahoo.com"};
//		ArrayList<Student> alstd=new ArrayList<Student>();
		Vector<Student> alstd=new Vector<Student>();
		for (int i = 0; i < arr3.length; i++) {
			Student std=new Student();
			std.setSid(arr1[i]);
			std.setSname(arr2[i]);
			std.setSemail(arr3[i]);
			alstd.add(std);
		}
//		Iterator<Student> itrs=alstd.iterator();
//		while(itrs.hasNext()) {
////			Student st=(Student)itrs.next();
////			System.out.println(st.getSid()+" "+st.getSname()+" "+st.getSemail());
//			System.out.println(itrs.next());
//			System.out.println("*********************");
//		}
		
//		for(Student s:alstd) {
//			System.out.println(s);
//		}
		
//		alstd.forEach(System.out::println);
		
//		for (int i = 0; i < alstd.toArray().length; i++) {
//			System.out.println(alstd.get(i));
//		}
		
//		int y=0;
//		while(y<alstd.toArray().length) {
//			System.out.println(alstd.get(y));
//			y++;
//		}
		
//		ListIterator<Student> ls=alstd.listIterator();
//		System.out.println("**************Forward iteration***************");
//		while(ls.hasNext()) {
//			System.out.println(ls.next());
//		}
//		System.out.println("**************Backward iteration***************");
//		while(ls.hasPrevious()) {
//			System.out.println(ls.previous());
//		}
		
		//Convert String Array To Collection
		String[] arr= {"Charukesi","Vasanth","Basanth Bahar","Malhar","Hamsadhwani"};
		List<String> ls=Arrays.asList(arr);
		Iterator<String> itra=ls.iterator();
		while(itra.hasNext()) {
			System.out.println(itra.next());
		}
		Integer[] arr21= {201,1,33,2,77,6,66};
		Arrays.sort(arr21);
		System.out.println(Arrays.toString(arr21));
		
		Arrays.fill(arr21, 10);
		System.out.println(Arrays.toString(arr21));
		
		//Creating empty lists without initializing the list object
		List s =Collections.EMPTY_LIST;
		Collections.emptyList();
		
		
		
		
		
		
		
		
	}
}
