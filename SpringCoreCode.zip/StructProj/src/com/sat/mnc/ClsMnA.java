package com.sat.mnc;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;
import java.util.function.Consumer;

public class ClsMnA {
	public static void main(String[] args) {
		String[] arr= {"Delhi","Prayagraj","Varnasi","Kanpur","Patna"};
		ArrayList<String> al=new ArrayList<String>();
//		Vector<String> al=new Vector<String>();
		for(String j:arr) {
			al.add(j);
		}
//		Iterator<String> itr=al.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
//		}	
		//Bi directional iteration
//		ListIterator<String> ls =al.listIterator();
//		while(ls.hasNext()) {
//			System.out.println(ls.next());
//		}
//		while(ls.hasPrevious()) {
//			System.out.println(ls.previous());
//		}
//		al.forEach(new Consumer<String>() {
//			@Override
//			public void accept(String t) {
//				System.out.println(t);
//			}
//		});
//		al.forEach(n->System.out.println(n));
		al.forEach(System.out::println);
	}
}
