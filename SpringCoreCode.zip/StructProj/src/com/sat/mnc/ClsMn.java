package com.sat.mnc;

import com.sat.cls.HashTabCls;
import com.sat.cls.LListCls;
import com.sat.cls.SetFamilyCls;
import com.sat.cls.StackCls;
import com.sat.cls.VectorCls;

public class ClsMn {

	public static void main(String[] args) {

//		StackCls.prnStack();
//		VectorCls.retVec();
//		VectorCls.retAList();
//		LListCls.llList();
//		SetFamilyCls.prnHashset();
//		SetFamilyCls.prnLinHasSet();
//		SetFamilyCls.prnTreeSe();
//		HashTabCls.retHashTab();
//		HashTabCls.prnHashMap();
//		HashTabCls.prnLinkedHashMap();
		HashTabCls.prnTreeMap();
		
		
		
		
	}

}
