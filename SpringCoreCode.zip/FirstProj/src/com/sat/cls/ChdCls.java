package com.sat.cls;

public class ChdCls extends BasCls {
	@Override
	public String retRev(String t) {
		StringBuffer buf=new StringBuffer(t);
		String a=buf.reverse().toString();
		return a;
	}
}
