package com.sat.cls;

public class MnCls {
	
	
	
	

	public static void main(String[] args) {
		ChdClsA cls = new ChdClsA();
		System.out.println(cls.retRev("Satish"));
		cls.myMeth();
		//Anonymous implementation
		BasCls clsa = new BasCls() {
			@Override
			public String retRev(String t) {
				StringBuilder bb = new StringBuilder(t);
				return bb.reverse().toString();
			}
		};
		System.out.println(clsa.retRev("Jagdish"));
		MyFuncClass clsF=new MyFuncClass() {
			@Override
			public int retSum(int a, int b) {
				return a+b;
			}
			@Override
			public double retRoot(int a) {
				return Math.sqrt(a);
			}
			@Override
			public String retCaps(String a) {
				return a.toUpperCase();
			}
		};
		System.out.println(clsF.retCaps("satish"));
		System.out.println(clsF.retRoot(2));
		System.out.println(clsF.retSum(2, 3));
		
		
		BasCls clsB=new ChdClsB();
		System.out.println(clsB.retRev("Suresh"));
		
		ImplIFace iFace=new ImplIFace();
		System.out.println(iFace.retCaps("jayesh"));
		System.out.println(iFace.strLower("SATISH"));
		
	}

}
