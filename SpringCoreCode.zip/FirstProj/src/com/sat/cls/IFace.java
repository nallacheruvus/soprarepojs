package com.sat.cls;

public interface IFace {
	public String retCaps(String h);
}
