package com.sat.cls;

public class DevCls implements IConnect {

	@Override
	public String retConn() {
		return "jdbc:mysql://185.54.77.33:3306/test";
	}

}
