package com.sat.cls;

public class ImplIFace implements IFace,IFaceLower {
	@Override
	public String retCaps(String h) {
		return h.toUpperCase();
	}

	@Override
	public String strLower(String h) {
		return h.toLowerCase();
	}
	
	
	public void tester() {
		System.out.println("Tester Method");
	}
}
