package com.sat.cls;

public abstract class MyFuncClass {
	public abstract String retCaps(String a);
	public abstract int retSum(int a,int b);
	public abstract double retRoot(int a);
}
