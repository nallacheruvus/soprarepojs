package com.sat.cls;

public abstract class BasCls {
	public abstract String retRev(String t);
	
	public void myMeth() {
		System.out.println(Math.sqrt(2));
	}
}
