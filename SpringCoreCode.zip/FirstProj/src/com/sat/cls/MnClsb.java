package com.sat.cls;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class MnClsb {

	public static void main(String[] args) throws IOException, URISyntaxException {
		//Factory pattern
		Runtime rr=Runtime.getRuntime();
//		try {
//			rr.exec("notepad.exe");
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		System.out.println(rr.availableProcessors());
//		rr.gc();
//		Desktop desk=Desktop.getDesktop();
//		desk.browse(new URI("http://www.google.com"));
	}

}
