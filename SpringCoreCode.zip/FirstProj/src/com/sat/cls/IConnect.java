package com.sat.cls;

public interface IConnect {
	public String retConn();
}
