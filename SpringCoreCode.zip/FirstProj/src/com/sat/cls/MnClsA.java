package com.sat.cls;

public class MnClsA {
	
	enum MyDbs{
		DEV,PROD,TEST,STAGE
	}
	
	static void callInter(IFace a,IFaceLower b,String h) {
		System.out.println(a.retCaps(h));
		System.out.println(b.strLower(h));
	}
	
	static void prnConn(IConnect cc) {
		System.out.println(cc.retConn());
	}

	public static void main(String[] args) {
//		MyDbs db=MyDbs.STAGE;
//		System.out.println(db.ordinal());
//		ImplIFace objA=new ImplIFace();
//		objA.tester();
//		ImplIFaceA objB=new ImplIFaceA();
//		IFace objAa=objA;
//		IFaceLower objBb=objB;
//		callInter(objAa, objBb, "suresh");
//		ProdCls cls=new ProdCls();
//		DevCls clsa=new DevCls();
//		IConnect clsb=new IConnect() {
//			@Override
//			public String retConn() {
//				return "jdbc:mysql://182.563.773.33:3306/test";
//			}
//		};
//		prnConn(clsb);
		ImplFam fam=new ImplFam();
		String j=fam.retMyStr("satish");
		System.out.println(j);
		IFamiliar.retMyStrA("satish");
		fam.prnRoot();
		IFamiliar fam2=new IFamiliar() {
		};
		System.out.println(fam2.retMyStr("Krishna"));
		Integer ia=100;
		Float ib=20.5555f;
		Double ic=89.99999;
		Character id='d';
		Boolean ie=true;
		Object yy=100;
		//Autoboxing
		
		
		
		
		
	}

	private static void retMyStr(String string) {
		// TODO Auto-generated method stub
		
	}
}
