package com.sat.cls;

public class ImplIFaceA implements IFace, IFaceLower {

	@Override
	public String strLower(String h) {
		return "****"+h.toLowerCase();
	}

	@Override
	public String retCaps(String h) {
		return "****"+h.toUpperCase();
	}

}
