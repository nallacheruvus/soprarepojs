package com.sat.cls;

public class ImplFam implements IFamiliar,IFamiliarA {

	@Override
	public void retAA() {
		IFamiliar.super.retAA();
	}

	public int retSum(int a,int b) {
		return a+b;
	}
	
	public float retSum(float a,float b) {
		return a+b;
	}
	
}
