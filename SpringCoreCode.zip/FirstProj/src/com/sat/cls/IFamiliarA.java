package com.sat.cls;

public interface IFamiliarA {
	default void prnRoot() {
		System.out.println(Math.sqrt(5));
	}
	
	default void retAA() {
		System.out.println("Test");
	}
}
