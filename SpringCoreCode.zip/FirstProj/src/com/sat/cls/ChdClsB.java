package com.sat.cls;

public class ChdClsB extends BasCls {

	@Override
	public String retRev(String t) {
		String u="";
		char[] arr=t.toCharArray();
		for (int i =arr.length-1; i >= 0; i--) {
			u+=arr[i];
		}
		return u;
	}

}
