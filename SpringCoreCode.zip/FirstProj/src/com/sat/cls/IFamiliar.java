package com.sat.cls;

public interface IFamiliar {

	default String retMyStr(String j) {
		return j.repeat(3);
	}
	
	static void retMyStrA(String j) {
		System.out.println(j.substring(0, 3));
	}
	
	default void retAA() {
		System.out.println("Test");
	}
	
}
