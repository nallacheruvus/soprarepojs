package com.sat.cls;

public interface IFaceLower {
	public String strLower(String h);
}
