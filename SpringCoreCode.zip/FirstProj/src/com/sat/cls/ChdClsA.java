package com.sat.cls;

public class ChdClsA extends BasCls {
	@Override
	public String retRev(String t) {
		StringBuilder bui=new StringBuilder(t);
		String u=bui.reverse().toString();
		return u;
	}
}
