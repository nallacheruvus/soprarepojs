package com.sat.cls;

public class MnCls {

	public static void main(String[] args) {

		for (int i = 1; i <= 20; i++) {
//			System.out.println(Math.pow(i, 2));
			System.out.printf("\t\tLog(%d)=%f\n",i,Math.log(i));
		}
		
		Integer y=100;
		System.out.println(y instanceof Integer);
		
		Object aa=null;
		System.out.println(aa instanceof Object);
		
		
		
		
		
	}

}
