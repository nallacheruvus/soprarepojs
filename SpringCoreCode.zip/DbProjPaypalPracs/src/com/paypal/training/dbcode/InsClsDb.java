package com.paypal.training.dbcode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsClsDb {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
			//PreparedStatement ps=conn.prepareStatement("insert into register values(7,'Rajiv','rajiv@yahoo.com','949494994949')");
			PreparedStatement ps=conn.prepareStatement("insert into register values(?,?,?,?)");
			ps.setInt(1, 8);
			ps.setString(2, "John");
			ps.setString(3, "john@yahoo.com");
			ps.setString(4, "94949494949");
			ps.execute();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}
}
