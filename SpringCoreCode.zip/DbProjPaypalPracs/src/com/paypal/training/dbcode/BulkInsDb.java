package com.paypal.training.dbcode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BulkInsDb {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
//		int[] arr1= {81,91,110,111,121};
//		String[] arr2= {"Hanumanji","Anjaneyaji","Marutiji","Vayuputraji","Sayidaji"};
//		String[] arr3={"Hanuman@yahoo.com","Anjaneya@yahoo.om","Maruti@yahoo.om","Vayuputra@yahoo.om","Sayida@yahoo.com"};
//		String[] arr4= {"94949499459","7575775757557","6565654665656","77676767666","66464664646"};
		
//		for (int i = 0; i < arr4.length; i++) {
//			String query="insert into register values ("+arr1[i]+",'"+arr2[i]+"','"+arr3[i]+"','"+arr4[i]+"')";
//			PreparedStatement ps=conn.prepareStatement(query);
//			ps.execute();
			
//			PreparedStatement ps=conn.prepareStatement("insert into register values(?,?,?,?)");
//			ps.setInt(1, arr1[i]);
//			ps.setString(2, arr2[i]);
//			ps.setString(3, arr3[i]);
//			ps.setString(4, arr4[i]);
//			ps.execute();
//			
//		}	

		Statement st=conn.createStatement();
		ArrayList<Register> rAl=new ArrayList<Register>();
		ResultSet rs=st.executeQuery("select * from register");
		while(rs.next()){
			Register rr=new Register(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			rAl.add(rr);
		}
		
		rAl.stream().filter(n->n.getRid()<=5).forEach(n->System.out.println(n));
		
		
		
		
		
	
	
	}
}
