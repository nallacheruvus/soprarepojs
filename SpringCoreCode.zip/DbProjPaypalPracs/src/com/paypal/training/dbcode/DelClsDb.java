package com.paypal.training.dbcode;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DelClsDb {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
//		PreparedStatement ps=conn.prepareStatement("delete from register where rid=?");
//		ps.setInt(1, 8);
//		ps.executeUpdate();
		
//		Statement st=conn.createStatement();
//		ResultSet rs=st.executeQuery("select avg(rid) as a from register");
//		while(rs.next()) {
//			System.out.println(rs.getInt(1));
//		}
		
		CallableStatement cs=conn.prepareCall("call myproc()");
		ResultSet rs= cs.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4));
		}
		
		
		
		
		
		
	}
}
