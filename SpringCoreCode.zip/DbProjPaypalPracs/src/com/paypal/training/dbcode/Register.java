package com.paypal.training.dbcode;

public class Register {
	private int rid;
	private String rname;
	private String remail;
	public int getRid() {
		return rid;
	}
	public String getRname() {
		return rname;
	}
	public String getRemail() {
		return remail;
	}
	public String getRmobile() {
		return rmobile;
	}
	private String rmobile;
	public Register() {
	}
	public Register(int a,String b,String c,String d) {
		this.rid=a;
		this.rname=b;
		this.remail=c;
		this.rmobile=d;
	}
	@Override
	public String toString() {
		return this.rid+" "+this.rname+" "+this.remail+" "+this.rmobile;
	}
}