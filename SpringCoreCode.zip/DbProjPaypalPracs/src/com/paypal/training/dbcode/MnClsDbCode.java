package com.paypal.training.dbcode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MnClsDbCode {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from register");
			while(rs.next()) {
				System.out.printf("ID:%d\tName:%s\tEmail:%s\tMobile:%s\n",rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
