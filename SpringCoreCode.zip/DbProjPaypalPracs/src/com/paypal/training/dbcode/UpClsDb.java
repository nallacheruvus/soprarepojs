package com.paypal.training.dbcode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpClsDb {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
		PreparedStatement ps=conn.prepareStatement("update register set rname=?,remail=?,rmobile=? where rid=?");
		ps.setString(1, "Johnny");
		ps.setString(2, "johnny@gmail.com");
		ps.setString(3, "93939393939");
		ps.setInt(4, 8);
		ps.executeUpdate();
		
	}

}
