package com.paypal.training.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracPaypalServicesAApplicationTests {

	@Test
	void contextLoads() {
	}

}
