package com.paypal.training.mods;

import java.util.ArrayList;
import java.util.List;

public class HelperPersons {

	List<Person> lPers=new ArrayList<Person>();
	
	public List<Person> retList(){
		int[] arr1= {1,2,3,4,5,6};
		String[] arr2= {"Ganesh","Sahil","Prem","Gaman","Ramani","Ram"}; 
		String[] arr3= {"Ganesh@yahoo.com","Sahil@yahoo.com","Prem@yahoo.com","Gaman@yahoo.com","Ramani@yahoo.com","Ram@yahoo.com"};
		for (int i = 0; i < arr3.length; i++) {
			Person pp=new Person();
			pp.setPid(arr1[i]);
			pp.setPname(arr2[i]);
			pp.setPemail(arr3[i]);
			lPers.add(pp);
		}
		return lPers;
	}
	
	
	
	
	
	
	
}
