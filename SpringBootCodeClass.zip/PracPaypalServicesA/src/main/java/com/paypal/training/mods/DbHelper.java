package com.paypal.training.mods;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DbHelper {
	Connection conn=null;
	public DbHelper() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/paypaldb", "root", "admin");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Selects all rows from logins table returns it as a list
	 * @return list of logins 
	 */
	public List<Logins> retLogins(){
		List<Logins> lstLogins=new ArrayList<Logins>();
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rs=st.executeQuery("select * from logins");
			while(rs.next()) {
				Logins ll=new Logins();
				ll.setUsername(rs.getString(1));
				ll.setPassword(rs.getString(2));
				lstLogins.add(ll);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lstLogins;
	}
	
	/**
	 * Inserts a new row into login table
	 * @param l Logins object
	 * @return status
	 */
	public String insLogins(Logins l) {
		String status="Row Inserted";
		try {
			PreparedStatement ps=conn.prepareStatement("insert into logins values(?,?)");
			ps.setString(1, l.getUsername());
			ps.setString(2, l.getPassword());
			ps.execute();
		} catch (SQLException e) {
			status="Not Inserted";
			e.printStackTrace();
		}
		return status;
	}
	
	/**
	 * Updates a row in logins table
	 * @param l takes a login object
	 * @return status
	 */
	public String upLogins(Logins l) {
		String status="Row Updated";
		try {
			PreparedStatement ps=conn.prepareStatement("update logins set password=? where username=?");
			ps.setString(1,l.getPassword() );
			ps.setString(2, l.getUsername());
			ps.executeUpdate();
		} catch (SQLException e) {
			status="Not Updated";
			e.printStackTrace();
		}
		return status;
	}
	
	/**
	 * Deletes a row based on the primary key in logins table
	 * @param uname username
	 * @return status
	 */
	public String delLogins(String uname) {
		String status="Row Deleted";
		try {
			PreparedStatement ps=conn.prepareStatement("delete from logins where username=?");
			ps.setString(1, uname);
			ps.executeUpdate();
		} catch (SQLException e) {
			status="Not Deleted";
			e.printStackTrace();
		}
		return status;
	}
}