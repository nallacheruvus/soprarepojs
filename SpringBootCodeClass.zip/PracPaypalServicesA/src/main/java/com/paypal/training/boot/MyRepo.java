package com.paypal.training.boot;

import org.springframework.stereotype.Repository;

@Repository
public class MyRepo {
	public String[] retArr() {
		return new String[]{"Gauri","Ganesh","Mahesh","Dinesh","Suresh"};
	}
}
