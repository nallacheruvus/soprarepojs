package com.paypal.training.boot;

import org.springframework.stereotype.Component;

@Component
public class MyComp {
	public Integer[] retAr() {
		return new Integer[] {25,22,23,24,21};
	}
}
