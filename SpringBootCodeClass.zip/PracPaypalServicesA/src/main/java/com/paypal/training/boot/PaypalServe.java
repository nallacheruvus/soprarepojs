package com.paypal.training.boot;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.training.mods.DbHelper;
import com.paypal.training.mods.HelperPersons;
import com.paypal.training.mods.Logins;
import com.paypal.training.mods.Person;

@RestController
public class PaypalServe {

	HelperPersons helper=new HelperPersons();
	
	
	@GetMapping("/first")
	public String retStr() {
		return "Welcome to Spring web services";
	}
	

	
	@GetMapping("/per")
	public Person retPer() {
		Person pp=new  Person();
		pp.setPid(1);
		pp.setPname("Hanif");
		pp.setPemail("hanif@yahoo.com");
		return pp;
	}
	
	@PostMapping("/retlp")
	private List<Person> retList() {
		return helper.retList();
	}
	
	@PutMapping("/sec")
	public String retStrA() {
		return "Send Across An Army To Limit The Power";
	}
	
	@DeleteMapping("/third")
	public double retRoot() {
		return Math.sqrt(2);
	}
	
	//Service code for crud ops on logins table
	DbHelper dbHelper=new DbHelper();
	
	@GetMapping("/rlogins")
	public List<Logins> retLogins(){
		return dbHelper.retLogins();
	}
	
	@PostMapping("/ilogins/{username}/{password}")
	public String insLogins(@PathVariable("username") String username,@PathVariable("password") String password) {
		Logins l=new Logins();
		l.setUsername(username);
		l.setPassword(password);
		return dbHelper.insLogins(l);
	}
	
	@PutMapping("/ulogins/{username}/{password}")
	public String upLogins(@PathVariable("username") String username,@PathVariable("password") String password) {
		Logins l=new Logins();
		l.setUsername(username);
		l.setPassword(password);
		return dbHelper.upLogins(l);
	}
	
	@DeleteMapping("/dlogins/{username}")
	public String delLogins(@PathVariable("username") String username) {
		return dbHelper.delLogins(username);
	}

	
}
