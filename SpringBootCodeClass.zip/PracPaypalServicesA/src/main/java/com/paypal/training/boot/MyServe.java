package com.paypal.training.boot;

import org.springframework.stereotype.Service;

@Service
public class MyServe {
	public Float[] retFlo() {
		return new Float[] {21.22222f,43.44444f,54.55555f,66.77777f,88.88888f};
	}
}
