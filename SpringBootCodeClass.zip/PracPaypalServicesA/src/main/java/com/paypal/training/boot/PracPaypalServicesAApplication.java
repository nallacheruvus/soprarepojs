package com.paypal.training.boot;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.Banner.Mode;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracPaypalServicesAApplication implements ApplicationRunner {
	@Autowired
	private MyRepo repo;
	@Autowired
	private MyServe serv;
	@Autowired
	private MyComp comp;
	
	public static void main(String[] args) {
		//SpringApplication.run(PracPaypalServicesAApplication.class, args);
		SpringApplication app=new SpringApplication(PracPaypalServicesAApplication.class);
		app.setBannerMode(Mode.OFF);
		app.run(args);
	}

	@Value("${db.url}")
	private String tester;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("^^^^^^"+tester);
		String arr[]=repo.retArr();
		for(String j:arr) {
			System.out.println("******"+j);
		}
		Arrays.asList(serv.retFlo()).forEach(n->System.out.println(n));
		Arrays.asList(comp.retAr()).forEach(System.out::println);
		Arrays.asList(comp.retAr()).stream().sorted().forEachOrdered(n->System.out.println(n));
	}
}
