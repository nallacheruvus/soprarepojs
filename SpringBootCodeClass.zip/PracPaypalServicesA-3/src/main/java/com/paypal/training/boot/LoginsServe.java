package com.paypal.training.boot;

import java.awt.print.Book;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginsServe {

//	@Autowired
//	private LoginsRepository repo;
	
	@Autowired
	private BooksRepository brepo;
	
//	@GetMapping("/logins")
//	public List<Logins> retLogins(){
//		List<Logins> ll=repo.findAll();
//		return ll;
//	}
//	
//	@GetMapping("/ins/{username}/{password}")
//	public Logins insLogins(@PathVariable("username") String username,@PathVariable("password") String password) {
//		Logins ll=new Logins();
//		ll.setUsername(username);
//		ll.setPassword(password);
//		repo.save(ll);
//		return ll;
//	}
//	
//	@GetMapping("/ups/{username}/{password}")
//	public Logins upsLogins(@PathVariable("username") String username,@PathVariable("password") String password) {
//		Logins ll=new Logins();
//		Optional<Logins> la=repo.findById(username);
//		ll=la.get();
//		ll.setPassword(password);
//		repo.save(ll);
//		return ll;
//	}
//	
//	@GetMapping("/del/{username}")
//	public String delLogi(@PathVariable("username") String username) {
//		Optional<Logins> la=repo.findById(username);
//		Logins l=la.get();
//		repo.delete(l);
//		return username;
//	}
	
	@GetMapping("/books")
	public List<Books> retBooks(){
		return brepo.findAll();
	}
	
	@GetMapping("/insb/{bid}/{bname}/{bauth}")
	public Books insBooks(@PathVariable("bid") int bid,@PathVariable("bname") String bname,@PathVariable("bauth") String bauth) {
		Books bb=new Books();
		bb.setBid(bid);
		bb.setBname(bname);
		bb.setBauth(bauth);
		brepo.save(bb);
		return bb;
	}
	
	@GetMapping("/upsb/{bid}/{bname}/{bauth}")
	public Books upsBooks(@PathVariable("bid") int bid,@PathVariable("bname") String bname,@PathVariable("bauth") String bauth) {
		Books bb=new Books();
		Optional<Books> b=brepo.findById((long)bid);
		bb=b.get();
		bb.setBname(bname);
		bb.setBauth(bauth);
		brepo.save(bb);
		return bb;
	}
	
}
