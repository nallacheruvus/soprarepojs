package com.paypal.training.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracPaypalServicesA2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
