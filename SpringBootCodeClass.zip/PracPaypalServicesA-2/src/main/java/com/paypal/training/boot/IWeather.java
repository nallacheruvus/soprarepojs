package com.paypal.training.boot;

public interface IWeather {
	public String retSeason();
}
