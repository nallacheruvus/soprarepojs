package com.paypal.training.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.paypal.training.boot.except.PayPalException;

@RestController
public class PaypalServe {

	@PostMapping("/test")
	public Person retTt(@RequestBody Person t) {
		String u=t.getName()+" "+t.getEmail();
		return t;
	}
	
	@Autowired
	RestTemplate temp;
	
	
	@GetMapping("/tt")
	public Person tt() {
		Person pp=new Person();
		pp.setName("Sunil");
		pp.setEmail("sunil@yahoo.com");
		ResponseEntity<String> ent= temp.getForEntity("https://jsonplaceholder.typicode.com/todos",String.class);
		System.out.println(ent.getBody());
		return pp;
	}
	
	@GetMapping("/ff")
	public String ffA() {
		throw new PayPalException("Dont run this method ever");
	}
	
	
}
