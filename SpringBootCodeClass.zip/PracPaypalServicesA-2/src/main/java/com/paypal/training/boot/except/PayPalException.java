package com.paypal.training.boot.except;

public class PayPalException extends RuntimeException {
	public PayPalException(String msg) {
		super(msg);
	}
}
