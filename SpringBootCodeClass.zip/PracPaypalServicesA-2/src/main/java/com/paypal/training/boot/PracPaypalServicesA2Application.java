package com.paypal.training.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class PracPaypalServicesA2Application implements ApplicationRunner {

	@Autowired
	private IWeather weather;
	
	public static void main(String[] args) {
		SpringApplication.run(PracPaypalServicesA2Application.class, args);
	}
	
	@Bean
	RestTemplate ret() {
		return new RestTemplate();
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println(weather.retSeason());
	}

}
