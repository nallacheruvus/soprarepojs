package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("win")
public class Winter implements IWeather {
	@Override
	public String retSeason() {
		return "Its Winter time snow all around";
	}
}
