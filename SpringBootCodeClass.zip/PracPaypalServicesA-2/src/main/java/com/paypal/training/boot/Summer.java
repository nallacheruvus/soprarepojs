package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("sum")
public class Summer implements IWeather {
	@Override
	public String retSeason() {
		return "Its Around Summer time now" ;
	}
}
