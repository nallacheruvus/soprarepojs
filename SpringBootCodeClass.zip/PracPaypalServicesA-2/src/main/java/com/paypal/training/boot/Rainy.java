package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("rain")
public class Rainy implements IWeather {
	@Override
	public String retSeason() {
		return "Rainy Season With Water All Around";
	}
}
