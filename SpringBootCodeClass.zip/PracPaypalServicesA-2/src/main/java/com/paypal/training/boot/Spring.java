package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("spring")
public class Spring implements IWeather {
	@Override
	public String retSeason() {
		return "Its Blooms Everywhere";
	}
}
