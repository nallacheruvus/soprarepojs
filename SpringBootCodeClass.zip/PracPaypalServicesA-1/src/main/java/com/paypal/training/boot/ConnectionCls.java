package com.paypal.training.boot;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConnectionCls {
	private String driver;
	private String url;
	private String username;
	private String password;
	public String getDriver() {
		return driver;
	}
	@Value("${db.driver}")
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getUrl() {
		return url;
	}
	@Value("${db.connection}")
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	@Value("${db.username}")
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	@Value("${db.password}")
	public void setPassword(String password) {
		this.password = password;
	}
}
