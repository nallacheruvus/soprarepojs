package com.paypal.training.boot;

public interface IMeter {
	public String retMeter();
}
