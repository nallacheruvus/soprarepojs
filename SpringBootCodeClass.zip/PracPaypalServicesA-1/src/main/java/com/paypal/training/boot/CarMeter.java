package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile({"carm","default"})
public class CarMeter implements IMeter {
	@Override
	public String retMeter() {
		return "Car Meter Is active now";
	}
}
