package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("autom")
public class AutoMeter implements IMeter {
	@Override
	public String retMeter() {
		return "Autometer is active now";
	}
}
