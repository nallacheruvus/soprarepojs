package com.paypal.training.boot;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("truckm")
public class TruckMeter implements IMeter {
	@Override
	public String retMeter() {
		return "Truck Meter is active now";
	}
}
