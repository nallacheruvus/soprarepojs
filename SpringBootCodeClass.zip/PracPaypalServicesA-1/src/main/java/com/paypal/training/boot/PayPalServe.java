package com.paypal.training.boot;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PayPalServe {

	
	
	
}
