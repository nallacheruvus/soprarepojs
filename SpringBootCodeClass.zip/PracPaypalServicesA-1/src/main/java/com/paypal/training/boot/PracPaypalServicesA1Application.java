package com.paypal.training.boot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracPaypalServicesA1Application implements CommandLineRunner {

	@Autowired
	IMeter meter;
	
	@Autowired
	ConnectionCls ccls;
	
	public static void main(String[] args) {
		SpringApplication.run(PracPaypalServicesA1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println(meter.retMeter());
		System.out.println(ccls.getDriver()+" "+ccls.getUrl()+" "+ccls.getUsername()+" "+ccls.getPassword());
	}

}
